<h1>Welcome page</h1>
<?php $__currentLoopData = $products->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <img src="<?php echo e($item->file_path); ?>" width="200" height="200" alt="">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH E:\UPWORK\food-chain\server\food-chain\resources\views/welcome.blade.php ENDPATH**/ ?>